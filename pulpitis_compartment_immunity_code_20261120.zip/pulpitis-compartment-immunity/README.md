# Compartment-resolved immunity in irreversible pulpitis

Analysis code and numerical result tables for:

> **Compartment-resolved immunity in irreversible pulpitis: compositional bulk signals and a venular interface**  
> Zhongzhen Ren, School of Stomatology, Shandong Medical and Pharmaceutical University, Yantai 264003, China

This is the complete release archive accompanying the final manuscript and supplementary files. All analyses are secondary analyses of public data; no new sequencing or qPCR data were generated for this study. The manuscript focuses on compartment attribution of bulk signals, cross-cohort macrophage activation, and a venular interface. Exploratory machine-learning, drug-signature and photobiomodulation analyses are retained as supplementary material rather than primary mechanistic evidence.

## 1. Public datasets

| Dataset | Platform / design | Role |
|---|---|---|
| GSE77459 | Affymetrix Human Gene 2.1 ST, GPL17692; 6 healthy and 6 irreversible-pulpitis bulk samples | Discovery bulk transcriptome |
| GSE92681 | Agilent-045997 Arraystar human lncRNA microarray V3, GPL16956; 5 healthy and 7 pulpitis samples | Independent bulk M1/M2 sensitivity analysis |
| GSE185222 | 10x single-cell RNA-seq; 4 samples, 6,582 analysed cells | Compartment localisation and macrophage activation |
| E-MTAB-14896 | Parse Evercode WT v2 (NovaSeq X); 12 patients across healthy, early and advanced stages | Three-stage compartment and patient-level analyses |
| GSE193448 | 808 nm photobiomodulation qPCR panel | Descriptive supplementary panel only |

Processed public matrices must be obtained from GEO or ArrayExpress/BioStudies. Raw expression matrices and large RDS objects are not redistributed in this release. The scripts document how the included result tables were generated.

## 2. Directory layout

- `R/bulk/`: GSE77459/GSE92681 differential expression, enrichment, immune scores, PBM, drug-signature and bulk M1/M2 analyses.
- `R/singlecell/`: GSE185222 preparation, annotation, communication, trajectory, deconvolution and myeloid analyses.
- `R/emtab/`: E-MTAB-14896 three-stage composition, cell-type analyses, TF/pathway activity, communication, trajectory, robustness and patient-level effect sizes.
- `R/manuscript/`: current TIFF figure assembly (`60_` and `61_`). The legacy `19i_`/`19j_` manuscript generators encode pre-QC text and are deliberately excluded from this release ZIP; the audited DOCX files in the submission package are canonical.
- `results/bulk/`: numerical bulk outputs.
- `results/singlecell/`: numerical outputs from both single-cell cohorts and single-cell-informed bulk deconvolution.
- `MANIFEST_SHA256.csv`: relative path, size and SHA-256 for every release file.
- `CODE_VALIDATION.md`: parse checks, environment versions and figure-assembly verification.
- `package_versions.csv`: locally installed versions of the principal R packages.

The file manifest, rather than the old web-upload file count, is the authoritative inventory for this release.

## 3. Current figure mapping

| Output | Principal scripts / numerical inputs |
|---|---|
| Main Figs. 1–2; bulk supplementary figures and tables | `06_DEG_enrich_GSE77459.R`, `11_immune_ssgsea.R`, `29_GSEA.R`, `31_WGCNA.R`, `16_hub_ROC.R` |
| Main Fig. 3; GSE185222 localisation | `20_prep_GSE185222.R`, `21_annotate_GSE185222.R`, `27_keygene_localization.R` |
| Main Fig. 4 and patient-level compartment effects | `36_EMTAB_validate.R`, `40_EMTAB_endo_immune.R`, `56_endo_ratio_lopo.R`, `67_compartment_effect_sizes_patient_figure.R` |
| Main Fig. 5 and three-stage seven-gene localisation | `27_keygene_localization.R`, `40_EMTAB_endo_immune.R` |
| Cell-type enrichment and communication/trajectory analyses | `39_EMTAB_celltype_DE_GSEA.R`, `48_LR_EMTAB.R`, `50_EMTAB_comm_focus.R`, `51_pseudotime.R`, `57_LR_patient_perm.R` |
| **Main Fig. 7; Supplementary Figs. 29–31** | `58_myeloid_refine_M1M2.R`, `65_GSE92681_probe_annotation_M1M2.R`, `61_build_current_figures.py` |
| Supplementary Fig. 32 | `46_DSigDB_reversal.R`, `61_build_current_figures.py`; direction-aware positive control only |
| Supplementary Fig. 33 | `67_compartment_effect_sizes_patient_figure.R`, `61_build_current_figures.py` |
| Base figure assembly | `60_build_sr_figures.py` assembles main Figs. 1–6 and 8 plus Supplementary Figs. 1–28 |
| Current M1/M2 and patient-level figure assembly | `61_build_current_figures.py` assembles Fig. 7 and Supplementary Figs. 29–33 |

`60_build_sr_figures.py` no longer assigns the drug-signature panel to Fig. 7. `61_build_current_figures.py` copies the R-native TIFF for Supplementary Fig. 33 so that the submitted TIFF is reproduced exactly rather than rerendered from a separate PNG device.

## 4. Statistical and reporting notes

- Patient-level values are used for three-stage composition, TF/pathway activity and communication inference wherever applicable. Cell-level P values are descriptive because cells are nested within patients.
- The total-endothelial advanced-minus-healthy effect is +27.235 percentage points (95% CI −5.120 to 59.591; Welch P = 0.08234). Four patients per stage limit power.
- In the primary M1/M2 marker set, M1 and M2 increase together in both bulk cohorts, but M1-minus-M2 does not change significantly (GSE77459 P = 0.699; GSE92681 P = 0.755). With the alternative marker set, the corresponding P values are 0.041 and 0.106. The result is therefore marker-set dependent and is not described as a consistent global polarisation switch.
- E-MTAB myeloid M1-minus-M2 is not significant with either marker set (P = 0.122 and 0.885). GSE185222 also shows marker-set dependence; activation, interferon/antigen-presentation and M2-core programmes are reported alongside the alternative-set contrast.
- All 118 E-MTAB transcription factors were rechecked with stage-wise Kruskal–Wallis tests and Benjamini–Hochberg correction. STAT1 and MYC have nominal P = 0.04978707; the minimum BH q is 0.3894635 and no TF passes q < 0.05. The complete recalculation is `results/singlecell/TF_stage_KW_BH_recalculated.csv`.
- ROC estimates are apparent, in-sample estimates from the same 12 discovery samples used for candidate selection. Among genes displayed in Supplementary Fig. 6, TNF has AUC = 0.8888889 and the other displayed genes have AUC = 1.00. These values are not diagnostic performance estimates.
- The PBM analysis averages two Ct replicates per group and uses 72 non-missing paired LPS/PBM mean DeltaCt targets. It applies no replicate-concordance exclusion and no replicate-level differential-expression inference. Thirty-two of 72 targets reverse direction (exact binomial P = 0.41); this panel is descriptive only.
- Drug-signature enrichment is a pathway-recovery positive control, not evidence of drug efficacy.

## 5. Software and execution

The analyses were run locally with R 4.5.3 and Bioconductor 3.22. Figure assembly uses Python with Pillow; manuscript checks use python-docx and PyMuPDF. Principal installed package versions are listed in `package_versions.csv`.

Scripts retain the original Windows absolute paths for provenance. Before rerunning, edit the `BASE`, `RES`, `SC`, input and output constants to point to a local copy of the public data and this release. Do not densify the full E-MTAB matrix at once; process it patient by patient. Some scripts download annotation or MSigDB resources and therefore require network access.

`CODE_VALIDATION.md` distinguishes parse-only and figure-assembly checks from a complete end-to-end rerun. Raw large datasets are intentionally absent, so the release archive itself is not a one-click containerized rerun.

## 6. Release and citation

Repository: https://github.com/renzhongzhen/pulpitis-compartment-immunity  
Complete release archive: `pulpitis_compartment_immunity_code_20261120.zip`

This ZIP is the complete release archive. The public repository README identifies it as the authoritative release, and the `R/` and `results/` directories in the repository are browseable copies.

Code is provided under the MIT License (`LICENSE`). Public datasets remain subject to their original submitters' terms. If using this release, cite the manuscript and the specific release archive.

```
Ren Z. Compartment-resolved immunity in irreversible pulpitis: analysis code and result tables.
GitHub repository. https://github.com/renzhongzhen/pulpitis-compartment-immunity
```
