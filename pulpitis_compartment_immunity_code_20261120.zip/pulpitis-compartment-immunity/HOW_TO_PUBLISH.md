# Release notes and upload record

Release date: 21 November 2026.

Repository: https://github.com/renzhongzhen/pulpitis-compartment-immunity

Complete release archive: `pulpitis_compartment_immunity_code_20261120.zip`

The ZIP is the authoritative release. The repository `R/` and `results/` directories are browseable copies of the earlier web-uploaded layout; use the ZIP when exact final script or table versions are required. The manuscript Code availability statement cites this repository and this ZIP.

The archive contains the final 42 R scripts, 2 Python figure/manuscript builders, 75 CSV result tables, `MANIFEST_SHA256.csv`, `CODE_VALIDATION.md` and `package_versions.csv`. It intentionally excludes raw public matrices, intermediate RDS objects, local caches and the legacy pre-QC `19i_`/`19j_` manuscript generators.

Before public release, verify the ZIP hash against `MANIFEST_SHA256.csv` and confirm that the repository README still points to the same archive filename. Do not upload access tokens, raw data or local working files.
