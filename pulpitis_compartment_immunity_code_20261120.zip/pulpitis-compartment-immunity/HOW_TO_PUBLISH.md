# Upload checklist for the synchronized code release

This folder and `pulpitis_compartment_immunity_code_20261120.zip` are the local release candidate synchronized with the 20 November 2026 manuscript. They do not prove that the public repository or Zenodo record has already been updated.

## GitHub

1. Extract `pulpitis_compartment_immunity_code_20261120.zip` and upload its contents to https://github.com/renzhongzhen/pulpitis-compartment-immunity, replacing the outdated web-uploaded files. Preserve `R/` and `results/` as directories; do not flatten them into the repository root. Upload the ZIP contents rather than unrelated local working files: the legacy pre-QC `19i_`/`19j_` manuscript generators are intentionally not in the release.
2. Confirm that the repository README begins with **Compartment-resolved immunity in irreversible pulpitis** and lists all five datasets, including GSE92681.
3. Confirm that these current files are present:
   - `R/manuscript/61_build_current_figures.py`
   - `R/singlecell/58_myeloid_refine_M1M2.R`
   - `R/bulk/65_GSE92681_probe_annotation_M1M2.R`
   - `R/emtab/67_compartment_effect_sizes_patient_figure.R`
   - `results/bulk/ROC_AUC_displayed.csv`
   - `results/singlecell/TF_stage_KW_BH_recalculated.csv`
4. Compare the uploaded inventory with `MANIFEST_SHA256.csv`. Do not upload access tokens, local raw-data caches or large RDS objects.

## Zenodo

1. Create a new GitHub release with a new tag and allow the linked Zenodo integration to archive that release, or upload the synchronized ZIP as a new version manually.
2. Check the published file list and download the ZIP once. Verify that it contains the current README, scripts and result tables rather than the earlier 40-script/59-table snapshot.
3. Record the version-specific DOI and the concept DOI separately. If the version-specific DOI differs from the DOI printed in the manuscript, update the Code availability statement before submission.
4. Project archive link currently printed in the manuscript: https://doi.org/10.5281/zenodo.24370289

## Final consistency check

- `CODE_VALIDATION.md` reports parse and figure-assembly checks, not a claim that all raw-data analyses were rerun from the ZIP.
- `package_versions.csv` records the local R package environment.
- The manuscript, code README and archived release must use the same current title and figure mapping.
- Do not mark this external step complete until the public GitHub page and the published Zenodo version have both been inspected.
