# 28_LR_delta_plot.R : top differential ligand-receptor communications (deep caries vs healthy)
suppressMessages({ library(ggplot2); library(dplyr) })

d <- "C:/Users/19354/Doubao/chats/2026-11-18/new-chat/pulp_bioinfo/sc/results"
lr <- read.csv(file.path(d, "GSE185222_LR_delta_deep_vs_healthy.csv"))
lr <- lr[!is.na(lr$delta), ]
top <- lr %>% arrange(desc(delta)) %>% slice(1:20)
top$label <- paste0(top$key, "  (", round(top$delta, 2), ")")

p <- ggplot(top, aes(x = reorder(label, delta), y = delta)) +
  geom_col(fill = "#c0392b", width = 0.7) +
  coord_flip() +
  labs(x = "", y = expression(Delta~"communication score (deep caries - healthy)"),
       title = "Deep-caries communication gains") +
  theme_bw() +
  theme(axis.text.y = element_text(size = 7))
ggsave(file.path(d, "GSE185222_LR_delta_top20.png"), p, width = 7.5, height = 6, dpi = 300)
cat("DONE\n")
