# 58_myeloid_refine_M1M2.R
# Aim: test whether the "infiltration volume rather than polarisation" conclusion
# holds when M1/M2 is scored (a) within myeloid cells only, patient-level,
# and (b) with a second, non-overlapping literature marker set.
suppressPackageStartupMessages({
  library(Seurat); library(Matrix); library(org.Hs.eg.db); library(AnnotationDbi)
  library(ggplot2)
})
root <- "C:/Users/19354/Doubao/chats/2026-11-18/new-chat/pulp_bioinfo"
outdir <- file.path(root, "sc/results/myeloid_refine")
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

# primary sets used in the manuscript
m1 <- c("IL1B", "CXCL10", "PTGS2", "IL6", "CXCL9", "CD86", "NOS2", "TNF", "CCL3", "CCL4")
m2 <- c("CD163", "MRC1", "MSR1", "IL10", "ARG1", "CCL18", "TGFB1", "CD209")
# alternative, disjoint literature-derived set (Jablonski/Murray-style core markers)
m1_alt <- c("CXCL11", "IDO1", "KYNU", "IL12A", "IL23A", "CD80", "STAT1", "IRF1",
            "GBP1", "GBP5", "TAP1", "TAP2", "HLA-DRA", "CCL5", "SOCS1", "MARCO",
            "CXCL13", "CCL19", "CCL20", "IL15", "IL18")
m2_alt <- c("CCL13", "CCL14", "CCL17", "CCL22", "CCL23", "CCL24", "CCL26", "MERTK",
            "STAB1", "PPARG", "KLF4", "IRF4", "STAT6", "F13A1", "FN1", "CLEC10A",
            "FCER2", "VSIG4", "SIGLEC1", "TGM2", "ALOX15", "MRC2", "CD276")
cat("overlap primary vs alt: M1 =", length(intersect(m1, m1_alt)),
    " M2 =", length(intersect(m2, m2_alt)), "\n")

myeloid_mk <- c("LYZ", "CD68", "CSF1R", "AIF1", "LST1", "CD14", "FCGR3A", "S100A8",
                "S100A9", "ITGAM", "SPI1", "TYROBP", "FCER1G", "C1QA", "C1QB", "C1QC")
lymphoid_mk <- c("CD3D", "CD3E", "CD2", "TRAC", "IL7R", "CD79A", "MS4A1", "MZB1",
                 "JCHAIN", "NKG7", "GNLY", "KLRD1", "CD8A", "CD4")

# ================= E-MTAB-14896 =================
x <- readRDS(file.path(root, "ea960c355a014573b0e904afc349b633processedmatrix.rds"))
md <- x@meta.data
cnt <- LayerData(x, assay = "RNA", layer = "counts")
dat <- LayerData(x, assay = "RNA", layer = "data")
ens <- sub("\\..*$", "", rownames(dat))
sym <- mapIds(org.Hs.eg.db, keys = ens, keytype = "ENSEMBL", column = "SYMBOL", multiVals = "first")
keep <- !is.na(sym) & !duplicated(sym)
dat2 <- dat[keep, , drop = FALSE]; rownames(dat2) <- sym[keep]
cnt2 <- cnt[keep, , drop = FALSE]; rownames(cnt2) <- sym[keep]
lv <- levels(factor(as.character(md$samples)))
npat <- length(lv)
stage_of <- function(s) ifelse(grepl("^Healthy", s), "Healthy",
                        ifelse(grepl("^Early", s), "Early", "Advanced"))
stage_pat <- factor(stage_of(lv), levels = c("Healthy", "Early", "Advanced"))
stage_cell <- stage_pat[factor(as.character(md$samples), levels = lv)]

imm_cts <- levels(Idents(x))[grepl("Blood & Immune", levels(Idents(x)))]
cat("immune clusters:", paste(imm_cts, collapse = " | "), "\n")

# cluster-level myeloid vs lymphoid marker means
mk <- c(myeloid_mk, lymphoid_mk); mk <- mk[mk %in% rownames(dat2)]
cl_mean <- sapply(imm_cts, function(cc) Matrix::rowMeans(dat2[mk, Idents(x) == cc, drop = FALSE]))
cl_tab <- data.frame(cluster = imm_cts,
                     myeloid = colMeans(cl_mean[intersect(myeloid_mk, mk), , drop = FALSE]),
                     lymphoid = colMeans(cl_mean[intersect(lymphoid_mk, mk), , drop = FALSE]),
                     n_cells = as.integer(table(factor(Idents(x)[Idents(x) %in% imm_cts], levels = imm_cts))))
cl_tab$call <- ifelse(cl_tab$myeloid > 1.2 * cl_tab$lymphoid, "myeloid",
               ifelse(cl_tab$lymphoid > 1.2 * cl_tab$myeloid, "lymphoid", "mixed"))
write.csv(cl_tab, file.path(outdir, "EMTAB_immune_cluster_lineage.csv"), row.names = FALSE)
print(cl_tab)
write.csv(round(cl_mean, 3), file.path(outdir, "EMTAB_immune_cluster_marker_means.csv"))

# cell-level lineage scores within immune cells (z-scored marker means)
imm_cells <- which(Idents(x) %in% imm_cts)
lin_sub <- as.matrix(dat2[mk, imm_cells, drop = FALSE])
lin_z <- t(scale(t(lin_sub)))
cell_my <- colMeans(lin_z[intersect(myeloid_mk, rownames(lin_z)), , drop = FALSE])
cell_ly <- colMeans(lin_z[intersect(lymphoid_mk, rownames(lin_z)), , drop = FALSE])
cell_lineage <- ifelse(cell_my > cell_ly, "myeloid", "lymphoid")
names(cell_lineage) <- colnames(lin_sub)

myeloid_cts <- cl_tab$cluster[cl_tab$call == "myeloid"]
sel_cluster <- as.character(Idents(x)[imm_cells]) %in% myeloid_cts
if (length(myeloid_cts) > 0 && sum(sel_cluster) >= 100) {
  mye_cells <- imm_cells[sel_cluster]
  rule <- paste0("cluster-level (", paste(myeloid_cts, collapse = ", "), ")")
} else {
  mye_cells <- imm_cells[cell_lineage == "myeloid"]
  rule <- "cell-level lineage score"
}
cat("myeloid selection rule:", rule, "; cells =", length(mye_cells), "\n")

pat_mye <- factor(as.character(md$samples[mye_cells]), levels = lv)
ncell_tab <- data.frame(sample = lv, stage = stage_pat,
                        n_myeloid = as.integer(table(pat_mye)))
write.csv(ncell_tab, file.path(outdir, "EMTAB_myeloid_cells_per_patient.csv"), row.names = FALSE)
print(ncell_tab)

# patient-level pseudobulk within myeloid cells
ind <- sparseMatrix(i = seq_along(pat_mye), j = as.integer(pat_mye), x = 1,
                    dims = c(length(pat_mye), npat))
pb <- as.matrix(cnt2[, mye_cells, drop = FALSE] %*% ind)
keep_pat <- colSums(pb) > 0 & ncell_tab$n_myeloid >= 20
cat("patients kept for pseudobulk:", sum(keep_pat), "of", npat, "\n")
pb <- pb[, keep_pat, drop = FALSE]
lcpm <- log2(sweep(pb, 2, colSums(pb), "/") * 1e6 + 1)
pat_keep <- lv[keep_pat]; stage_keep <- stage_pat[keep_pat]

score_sets <- list(primary = list(M1 = m1, M2 = m2), alternative = list(M1 = m1_alt, M2 = m2_alt))
res_list <- list()
for (sn in names(score_sets)) {
  g1 <- intersect(score_sets[[sn]]$M1, rownames(lcpm))
  g2 <- intersect(score_sets[[sn]]$M2, rownames(lcpm))
  cat(sn, ": M1 genes used =", length(g1), " M2 genes used =", length(g2), "\n")
  cat("  M1:", paste(g1, collapse = ","), "\n  M2:", paste(g2, collapse = ","), "\n")
  d <- data.frame(sample = pat_keep, stage = stage_keep, set = sn,
                  n_myeloid = ncell_tab$n_myeloid[keep_pat],
                  M1 = colMeans(lcpm[g1, , drop = FALSE]),
                  M2 = colMeans(lcpm[g2, , drop = FALSE]))
  d$M1_minus_M2 <- d$M1 - d$M2
  res_list[[sn]] <- d
  cat("== patient-level myeloid", sn, "==\n")
  print(aggregate(cbind(M1, M2, M1_minus_M2) ~ stage, d, mean))
  cat("Kruskal M1 p=", kruskal.test(M1 ~ stage, d)$p.value,
      " M2 p=", kruskal.test(M2 ~ stage, d)$p.value,
      " M1-M2 p=", kruskal.test(M1_minus_M2 ~ stage, d)$p.value, "\n")
  if (all(c("Healthy", "Advanced") %in% d$stage)) {
    cat("Wilcoxon Advanced vs Healthy: M1 p=",
        wilcox.test(d$M1[d$stage == "Advanced"], d$M1[d$stage == "Healthy"])$p.value,
        " M2 p=", wilcox.test(d$M2[d$stage == "Advanced"], d$M2[d$stage == "Healthy"])$p.value,
        " M1-M2 p=", wilcox.test(d$M1_minus_M2[d$stage == "Advanced"],
                                 d$M1_minus_M2[d$stage == "Healthy"])$p.value, "\n")
  }
}
res <- do.call(rbind, res_list)
write.csv(res, file.path(outdir, "EMTAB_myeloid_M1M2_by_patient.csv"), row.names = FALSE)

# cell-level z-scored module scores within myeloid cells (same method as manuscript)
cell_res <- list()
for (sn in names(score_sets)) {
  gs <- unique(c(score_sets[[sn]]$M1, score_sets[[sn]]$M2))
  gs <- intersect(gs, rownames(dat2))
  sub <- as.matrix(dat2[gs, mye_cells, drop = FALSE])
  z <- t(scale(t(sub)))
  z <- z[apply(z, 1, function(r) all(is.finite(r))), , drop = FALSE]
  g1 <- intersect(score_sets[[sn]]$M1, rownames(z)); g2 <- intersect(score_sets[[sn]]$M2, rownames(z))
  if (length(g1) < 2 || length(g2) < 2) { cat(sn, ": too few variable genes at cell level\n"); next }
  sc <- data.frame(cell = colnames(z), set = sn,
                   stage = stage_cell[mye_cells],
                   sample = as.character(md$samples[mye_cells]),
                   M1 = colMeans(z[g1, , drop = FALSE]), M2 = colMeans(z[g2, , drop = FALSE]))
  sc$M1_minus_M2 <- sc$M1 - sc$M2
  cell_res[[sn]] <- sc
  cat("cell-level", sn, "M1-M2 Advanced vs Healthy Wilcoxon p=",
      wilcox.test(sc$M1_minus_M2[sc$stage == "Advanced"], sc$M1_minus_M2[sc$stage == "Healthy"])$p.value, "\n")
}
if (length(cell_res)) write.csv(do.call(rbind, cell_res), file.path(outdir, "EMTAB_myeloid_M1M2_cellscore.csv"), row.names = FALSE)

# plot patient-level scores
res$set <- factor(res$set, levels = c("primary", "alternative"))
pl <- rbind(data.frame(res[, c("sample", "stage", "set")], module = "M1", value = res$M1),
            data.frame(res[, c("sample", "stage", "set")], module = "M2", value = res$M2),
            data.frame(res[, c("sample", "stage", "set")], module = "M1-M2", value = res$M1_minus_M2))
p <- ggplot(pl, aes(x = stage, y = value, fill = stage)) +
  geom_boxplot(outlier.shape = NA, width = 0.55) +
  geom_point(size = 1.2, position = position_jitter(width = 0.12)) +
  facet_grid(module ~ set, scales = "free_y") +
  scale_fill_manual(values = c(Healthy = "#4C72B0", Early = "#DD8452", Advanced = "#C44E52")) +
  labs(x = NULL, y = "mean log2 CPM (patient pseudobulk)",
       title = "M1/M2 within myeloid cells only (E-MTAB-14896)") +
  theme_bw(base_size = 10) + theme(legend.position = "none")
ggsave(file.path(outdir, "EMTAB_myeloid_M1M2_two_sets.png"), p, width = 7.2, height = 7.4, dpi = 300)
ggsave(file.path(outdir, "EMTAB_myeloid_M1M2_two_sets.tiff"), p, width = 7.2, height = 7.4, dpi = 300, compression = "lzw")

rm(x, cnt, dat, dat2, cnt2); gc()

# ================= GSE185222 macrophages =================
obj <- readRDS(file.path(root, "sc/results/GSE185222_seurat_annotated.rds"))
mac <- subset(obj, celltype == "Macrophages/Monocytes")
cat("GSE185222 macrophages:", ncol(mac), "\n")
gse_sets <- list(primary = list(M1 = c("IL1B", "CXCL10", "PTGS2", "IL6", "CXCL9", "CD86"),
                                M2 = c("CD163", "MRC1", "MSR1", "IL10", "ARG1", "CCL18")),
                 alternative = list(M1 = m1_alt, M2 = m2_alt))
out <- list()
for (sn in names(gse_sets)) {
  g1 <- intersect(gse_sets[[sn]]$M1, rownames(mac)); g2 <- intersect(gse_sets[[sn]]$M2, rownames(mac))
  cat("GSE185222", sn, "M1 genes =", length(g1), " M2 genes =", length(g2), "\n")
  mac <- AddModuleScore(mac, features = list(g1, g2), name = paste0(sn, "_"), seed = 1)
  d <- mac@meta.data[, c("sample", "condition", paste0(sn, "_1"), paste0(sn, "_2"))]
  colnames(d) <- c("sample", "condition", "M1", "M2")
  d$M1_minus_M2 <- d$M1 - d$M2
  d$set <- sn
  out[[sn]] <- d
  cat(sn, "means by condition:\n")
  print(aggregate(cbind(M1, M2, M1_minus_M2) ~ condition, d, mean))
  cat(sn, "cell-level Wilcoxon M1-M2 p=",
      wilcox.test(d$M1_minus_M2[d$condition == "Deep caries"],
                  d$M1_minus_M2[d$condition == "Healthy/Enamel caries"])$p.value, "\n")
  cat(sn, "sample-level means:\n")
  print(aggregate(cbind(M1, M2, M1_minus_M2) ~ sample + condition, d, mean))
}
gd <- do.call(rbind, out)
write.csv(gd, file.path(outdir, "GSE185222_mac_M1M2_two_sets.csv"), row.names = FALSE)

pg <- ggplot(gd, aes(x = condition, y = M1_minus_M2, fill = condition)) +
  geom_boxplot(outlier.shape = NA, width = 0.5) +
  facet_wrap(~set) +
  scale_fill_manual(values = c("Healthy/Enamel caries" = "#4C72B0", "Deep caries" = "#C44E52")) +
  labs(x = NULL, y = "M1 minus M2 (AddModuleScore)",
       title = "Macrophage M1-M2 score, two marker sets (GSE185222)") +
  theme_bw(base_size = 10) + theme(legend.position = "none",
                                   axis.text.x = element_text(angle = 20, hjust = 1))
ggsave(file.path(outdir, "GSE185222_mac_M1M2_two_sets.png"), pg, width = 6.4, height = 3.8, dpi = 300)
ggsave(file.path(outdir, "GSE185222_mac_M1M2_two_sets.tiff"), pg, width = 6.4, height = 3.8, dpi = 300, compression = "lzw")
cat("DONE\n")
