# -*- coding: utf-8 -*-
"""Assemble current Figure 7 and Supplementary Figures 29-33 from real analysis plots."""
from pathlib import Path
import argparse
import shutil
from PIL import Image, ImageDraw, ImageFont

BASE = Path(r"C:\Users\19354\Doubao\chats\2026-11-18\new-chat\pulp_bioinfo")
RES = BASE / "results"
SC = BASE / "sc" / "results"
MYE = SC / "myeloid_refine"
SOURCES = {
    "Figure7.tif": "external_bulk_M1M2_modules.png;EMTAB_myeloid_M1M2_two_sets.png;GSE185222_mac_M1M2_two_sets.png;GSE185222_mac_subprogrammes.png",
    "SupplementaryFig29.tif": "EMTAB_myeloid_M1M2_two_sets.png",
    "SupplementaryFig30.tif": "GSE185222_mac_M1M2_two_sets.png;GSE185222_mac_subprogrammes.png (vertical composite)",
    "SupplementaryFig31.tif": "external_bulk_M1M2_modules.png",
    "SupplementaryFig32.tif": "DSigDB_drug_direction_top40.png",
    "SupplementaryFig33.tif": "EMTAB_compartment_patient_effects.png",
}


def rgb(path):
    im = Image.open(path)
    if im.mode in ("P", "RGBA", "LA"):
        rgba = im.convert("RGBA")
        bg = Image.new("RGB", rgba.size, "white")
        bg.paste(rgba, (0, 0), rgba)
        return bg
    return im.convert("RGB")


def save(im, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, format="TIFF", compression="tiff_lzw", dpi=(300, 300))


def build(outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    # Four-panel cross-cohort M1/M2 figure.
    panels = [
        ("a", RES / "external_bulk" / "external_bulk_M1M2_modules.png"),
        ("b", MYE / "EMTAB_myeloid_M1M2_two_sets.png"),
        ("c", MYE / "GSE185222_mac_M1M2_two_sets.png"),
        ("d", MYE / "GSE185222_mac_subprogrammes.png"),
    ]
    margin, gutter = 30, 30
    cell_w, top_h, bottom_h = 1470, 1770, 840
    canvas = Image.new("RGB", (margin * 2 + cell_w * 2 + gutter, margin * 2 + top_h + bottom_h + gutter), "white")
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype("arialbd.ttf", 64)
    positions = [(margin, margin, cell_w, top_h), (margin + cell_w + gutter, margin, cell_w, top_h),
                 (margin, margin + top_h + gutter, cell_w, bottom_h),
                 (margin + cell_w + gutter, margin + top_h + gutter, cell_w, bottom_h)]
    for (label, path), (x, y, w, h) in zip(panels, positions):
        im = rgb(path)
        im.thumbnail((w - 20, h - 20), Image.Resampling.LANCZOS)
        canvas.paste(im, (x + (w - im.width) // 2, y + (h - im.height) // 2))
        draw.rectangle((x + 4, y + 4, x + 86, y + 82), fill="white")
        draw.text((x + 12, y + 6), label, fill="black", font=font)
    save(canvas, outdir / "Figure7.tif")

    save(rgb(MYE / "EMTAB_myeloid_M1M2_two_sets.png"), outdir / "SupplementaryFig29.tif")
    a = rgb(MYE / "GSE185222_mac_M1M2_two_sets.png")
    b = rgb(MYE / "GSE185222_mac_subprogrammes.png")
    w = max(a.width, b.width)
    a = a.resize((w, round(a.height * w / a.width)), Image.Resampling.LANCZOS)
    b = b.resize((w, round(b.height * w / b.width)), Image.Resampling.LANCZOS)
    vertical = Image.new("RGB", (w, a.height + b.height + 40), "white")
    vertical.paste(a, (0, 0)); vertical.paste(b, (0, a.height + 40))
    save(vertical, outdir / "SupplementaryFig30.tif")
    save(rgb(RES / "external_bulk" / "external_bulk_M1M2_modules.png"), outdir / "SupplementaryFig31.tif")
    save(rgb(RES / "deep" / "DSigDB_drug_direction_top40.png"), outdir / "SupplementaryFig32.tif")
    shutil.copyfile(SC / "EMTAB_compartment_patient_effects.tif", outdir / "SupplementaryFig33.tif")

    manifest = outdir / "figure_manifest.txt"
    if manifest.exists():
        rows = {}
        for line in manifest.read_text(encoding="utf-8").splitlines()[1:]:
            name = line.split("\t", 1)[0]
            rows[name] = line
        for name, source in SOURCES.items():
            im = Image.open(outdir / name)
            rows[name] = f"{name}\t{im.width}\t{im.height}\t{im.width/300:.1f}x{im.height/300:.1f}\t{source}"
        order = [f"Figure{i}.tif" for i in range(1, 9)] + [f"SupplementaryFig{i}.tif" for i in range(1, 34)]
        text = "file\twidth_px\theight_px\t300dpi_inches\tsource_pngs\n" + "\n".join(rows[n] for n in order if n in rows) + "\n"
        manifest.write_text(text, encoding="utf-8")
    print("Built", ", ".join(SOURCES), "in", outdir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", type=Path, default=RES / "sr_figures")
    args = parser.parse_args()
    build(args.outdir)
