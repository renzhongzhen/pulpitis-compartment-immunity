# 65_GSE92681_probe_annotation_M1M2.R
# GPL16956 has no gene symbols, only 60-mer probe sequences.
# Annotate the target genes by exact 60-mer matching against RefSeq transcripts,
# then compare z-scored M1/M2 module scores in GSE92681 vs GSE77459.
suppressPackageStartupMessages({
  library(org.Hs.eg.db); library(AnnotationDbi); library(GEOquery); library(ggplot2)
})
root <- "C:/Users/19354/Doubao/chats/2026-11-18/new-chat/pulp_bioinfo"
data_dir <- file.path(root, "data")
outdir <- file.path(root, "results/external_bulk")
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

sets <- list(
  M1 = c("IL1B", "TNF", "IL6", "IL12B", "CXCL9", "CXCL10", "NOS2", "CD80", "CD86", "PTGS2"),
  M2 = c("CD163", "MRC1", "MSR1", "IL10", "TGFB1", "ARG1", "CCL18", "CCL22", "TGM2"),
  Monocyte = c("CD14", "LYZ", "CSF1R", "FCGR3A", "S100A12", "FPR1"),
  M1_alt = c("CXCL11", "IDO1", "KYNU", "IL12A", "IL23A", "CD80", "STAT1", "IRF1",
             "GBP1", "GBP5", "TAP1", "TAP2", "HLA-DRA", "CCL5", "SOCS1", "MARCO",
             "CXCL13", "CCL19", "CCL20", "IL15", "IL18"),
  M2_alt = c("CCL13", "CCL14", "CCL17", "CCL22", "CCL23", "CCL24", "CCL26", "MERTK",
             "STAB1", "PPARG", "KLF4", "IRF4", "STAT6", "F13A1", "FN1", "CLEC10A",
             "FCER2", "VSIG4", "SIGLEC1", "TGM2", "ALOX15", "MRC2", "CD276")
)
genes <- unique(unlist(sets))
cat("target genes:", length(genes), "\n")

plat <- read.csv(file.path(data_dir, "GPL16956_platform_table.csv"), stringsAsFactors = FALSE)
plat <- plat[plat$TRANSCRIPT_TYPE == "protein_coding", ]
probe_seq <- toupper(plat$SEQUENCE)
probe_id <- plat$ID
rc <- function(s) {
  m <- c(A = "T", T = "A", C = "G", G = "C", N = "N")
  sapply(strsplit(s, ""), function(x) paste(m[rev(x)], collapse = ""))
}
probe_rc <- rc(probe_seq)
seq_tab <- data.frame(id = probe_id, fwd = probe_seq, rev = probe_rc, stringsAsFactors = FALSE)

ref <- mapIds(org.Hs.eg.db, keys = genes, keytype = "SYMBOL", column = "REFSEQ", multiVals = "list")
fetch_seq <- function(acc) {
  u <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",
              acc, "&rettype=fasta&retmode=text")
  x <- tryCatch(readLines(u, warn = FALSE), error = function(e) NULL)
  if (is.null(x) || length(x) < 2) return(NULL)
  paste(x[!grepl("^>", x)], collapse = "")
}

ann <- list(); seq_cache <- list()
for (g in genes) {
  accs <- unlist(ref[[g]])
  accs <- accs[grepl("^NM_", accs)]
  accs <- head(unique(accs), 5)
  hits <- character(0); used <- character(0)
  for (a in accs) {
    if (is.null(seq_cache[[a]])) {
      seq_cache[[a]] <- fetch_seq(a); Sys.sleep(0.34)
    }
    s <- seq_cache[[a]]
    if (is.null(s) || nchar(s) < 60) next
    s <- toupper(s)
    n <- nchar(s) - 59
    km <- unique(substring(s, 1:n, 60:(n + 59)))
    h1 <- seq_tab$id[seq_tab$fwd %in% km]
    h2 <- seq_tab$id[seq_tab$rev %in% km]
    h <- unique(c(h1, h2))
    if (length(h)) { hits <- union(hits, h); used <- c(used, a) }
    if (length(hits) >= 1) break
  }
  ann[[g]] <- data.frame(gene = g, probes = paste(hits, collapse = ";"),
                         n_probes = length(hits), refseq = paste(used, collapse = ";"))
  cat(g, ":", length(hits), "probe(s)", ifelse(length(hits), paste0("[", used[1], "]"), ""), "\n")
}
ann <- do.call(rbind, ann)
write.csv(ann, file.path(outdir, "GSE92681_probe_annotation.csv"), row.names = FALSE)
cat("genes annotated:", sum(ann$n_probes > 0), "/", length(genes), "\n")

# expression matrix of annotated genes
gse <- getGEO(filename = file.path(data_dir, "GSE92681_series_matrix.txt.gz"), getGPL = FALSE)
grp81 <- factor(ifelse(grepl("inflam", pData(gse)$title, ignore.case = TRUE), "Pulpitis", "Normal"),
                levels = c("Normal", "Pulpitis"))
expr <- exprs(gse)
map_rows <- list()
for (g in ann$gene[ann$n_probes > 0]) {
  ps <- unlist(strsplit(ann$probes[ann$gene == g], ";"))
  ps <- intersect(ps, rownames(expr))
  if (!length(ps)) next
  sub <- expr[ps, , drop = FALSE]
  map_rows[[g]] <- sub[which.max(rowMeans(sub)), ]
}
E81 <- do.call(rbind, map_rows)
cat("GSE92681 annotated gene matrix:", nrow(E81), "x", ncol(E81), "\n")
write.csv(E81, file.path(outdir, "GSE92681_target_gene_expression.csv"))

# GSE77459 full matrix
e <- new.env(); load(file.path(data_dir, "GSE77459_genelevel.RData"), envir = e)
E59 <- as.matrix(e$expr_gene)
grp59 <- factor(e$grp, levels = c("Normal", "Pulpitis"))

module_score <- function(mat, grp, cohort) {
  z <- t(scale(t(mat)))
  z <- z[apply(z, 1, function(r) all(is.finite(r))), , drop = FALSE]
  out <- data.frame(sample = colnames(z), group = grp, cohort = cohort)
  for (sn in names(sets)) {
    g <- intersect(sets[[sn]], rownames(z))
    out[[sn]] <- colMeans(z[g, , drop = FALSE])
    attr(out, paste0("n_", sn)) <- length(g)
  }
  out
}
s59 <- module_score(E59, grp59, "GSE77459")
s81 <- module_score(E81, grp81, "GSE92681")
for (sn in names(sets)) cat("genes used:", sn, "GSE77459 =", attr(s59, paste0("n_", sn)),
                            " GSE92681 =", attr(s81, paste0("n_", sn)), "\n")

summ <- list()
for (coh in c("GSE77459", "GSE92681")) {
  d <- if (coh == "GSE77459") s59 else s81
  d$M1_minus_M2 <- d$M1 - d$M2
  d$M1alt_minus_M2alt <- d$M1_alt - d$M2_alt
  cat("\n==", coh, "==\n")
  for (v in c("M1", "M2", "M1_minus_M2", "Monocyte", "M1_alt", "M2_alt", "M1alt_minus_M2alt")) {
    a <- d[[v]][d$group == "Pulpitis"]; b <- d[[v]][d$group == "Normal"]
    p <- wilcox.test(a, b)$p.value
    cat(sprintf("%s: Normal %.3f -> Pulpitis %.3f (delta %.3f), Wilcoxon p = %.4g\n",
                v, mean(b), mean(a), mean(a) - mean(b), p))
    summ[[length(summ) + 1]] <- data.frame(cohort = coh, variable = v,
                                           normal = mean(b), pulpitis = mean(a),
                                           delta = mean(a) - mean(b), p = p)
  }
  if (coh == "GSE77459") s59 <- d else s81 <- d
}
write.csv(do.call(rbind, summ), file.path(outdir, "external_bulk_module_summary.csv"), row.names = FALSE)
write.csv(rbind(s59, s81), file.path(outdir, "external_bulk_module_scores.csv"), row.names = FALSE)

all <- rbind(s59, s81)
pl <- rbind(data.frame(all[, c("sample", "group", "cohort")], variable = "M1", value = all$M1),
            data.frame(all[, c("sample", "group", "cohort")], variable = "M2", value = all$M2),
            data.frame(all[, c("sample", "group", "cohort")], variable = "M1-M2", value = all$M1_minus_M2),
            data.frame(all[, c("sample", "group", "cohort")], variable = "Monocyte", value = all$Monocyte))
p <- ggplot(pl, aes(x = group, y = value, fill = group)) +
  geom_boxplot(outlier.shape = NA, width = 0.5) +
  geom_point(size = 1.2, position = position_jitter(width = 0.12)) +
  facet_grid(variable ~ cohort, scales = "free_y") +
  scale_fill_manual(values = c(Normal = "#4C72B0", Pulpitis = "#C44E52")) +
  labs(x = NULL, y = "z-scored module score",
       title = "M1/M2 module scores in two independent bulk cohorts") +
  theme_bw(base_size = 10) + theme(legend.position = "none")
ggsave(file.path(outdir, "external_bulk_M1M2_modules.png"), p, width = 6.8, height = 8.2, dpi = 300)
ggsave(file.path(outdir, "external_bulk_M1M2_modules.tiff"), p, width = 6.8, height = 8.2, dpi = 300, compression = "lzw")
cat("\nDONE\n")
