suppressPackageStartupMessages(library(tidyverse))

root <- "C:/Users/19354/Doubao/chats/2026-11-18/new-chat/pulp_bioinfo"
infile <- file.path(root, "sc", "results", "EMTAB_composition_by_sample.csv")
outdir <- file.path(root, "sc", "results")
dat <- read_csv(infile, show_col_types = FALSE)
dat$stage <- factor(dat$stage, levels = c("Healthy", "Early", "Advanced"))

endo_total <- dat %>%
  filter(celltype %in% paste("Endothelial cells", 1:4)) %>%
  group_by(sample, stage) %>%
  summarise(pct = sum(pct), .groups = "drop") %>%
  mutate(metric = "Endothelial total")
endo3 <- dat %>%
  filter(celltype == "Endothelial cells 3") %>%
  select(sample, stage, pct) %>%
  mutate(metric = "Endothelial 3")
fibro1 <- dat %>%
  filter(celltype == "Fibroblast & Stromal cells 1") %>%
  select(sample, stage, pct) %>%
  mutate(metric = "Fibroblast/Stromal 1")
key <- bind_rows(endo_total, endo3, fibro1) %>%
  mutate(metric = factor(metric, levels = c("Endothelial total", "Endothelial 3", "Fibroblast/Stromal 1")))

metrics <- levels(key$metric)
res <- lapply(metrics, function(m) {
  x <- key %>% filter(metric == m)
  a <- x %>% filter(stage == "Advanced") %>% pull(pct)
  h <- x %>% filter(stage == "Healthy") %>% pull(pct)
  e <- x %>% filter(stage == "Early") %>% pull(pct)
  tt <- t.test(a, h, var.equal = FALSE)
  tibble(
    metric = m,
    healthy_mean = mean(h),
    early_mean = mean(e),
    advanced_mean = mean(a),
    advanced_minus_healthy_pp = unname(tt$estimate[1] - tt$estimate[2]),
    ci95_low_pp = unname(tt$conf.int[1]),
    ci95_high_pp = unname(tt$conf.int[2]),
    welch_p = tt$p.value,
    n_healthy = length(h),
    n_early = length(e),
    n_advanced = length(a)
  )
}) %>% bind_rows()
write_csv(res, file.path(outdir, "EMTAB_compartment_effect_sizes.csv"))
print(res, digits = 5)

p <- ggplot(key, aes(stage, pct, fill = stage)) +
  geom_boxplot(width = 0.62, alpha = 0.65, outlier.shape = NA, colour = "grey25") +
  geom_point(position = position_jitter(width = 0.12, seed = 42), size = 2.0, colour = "black") +
  facet_wrap(~metric, scales = "free_y", nrow = 1) +
  scale_fill_manual(values = c(Healthy = "#4C78A8", Early = "#F28E2B", Advanced = "#C44E52")) +
  theme_bw(base_size = 14) +
  theme(legend.position = "none", strip.text = element_text(size = 14),
        axis.text.x = element_text(size = 12), panel.grid.minor = element_blank()) +
  labs(x = NULL, y = "Patient-level proportion (%)")

ggsave(file.path(outdir, "EMTAB_compartment_patient_effects.png"), p,
       width = 9.2, height = 3.8, dpi = 300, bg = "white")
tiff(file.path(outdir, "EMTAB_compartment_patient_effects.tif"),
     width = 9.2, height = 3.8, units = "in", res = 300,
     compression = "lzw", bg = "white")
print(p)
dev.off()
