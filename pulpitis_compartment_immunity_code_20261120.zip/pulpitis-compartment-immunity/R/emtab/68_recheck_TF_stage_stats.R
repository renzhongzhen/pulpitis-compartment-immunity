p <- "C:/Users/19354/Doubao/chats/2026-11-18/new-chat/pulp_bioinfo/sc/results/EMTAB_TF_activity.csv"
x <- read.csv(p, check.names = FALSE)
tfs <- unique(x$source)
out <- do.call(rbind, lapply(tfs, function(tf) {
  z <- x[x$source == tf, ]
  means <- sapply(c("Healthy", "Early", "Advanced"), function(s) mean(z$score[z$stage == s]))
  kw <- kruskal.test(z$score, factor(z$stage, levels = c("Healthy", "Early", "Advanced")))
  data.frame(TF = tf, Healthy = means[1], Early = means[2], Advanced = means[3], P = kw$p.value)
}))
out$BH <- p.adjust(out$P, method = "BH")
out <- out[order(out$P), ]
write.csv(out, "C:/Users/19354/Doubao/chats/2026-11-18/new-chat/pulp_bioinfo/results/submission_qc_20261120/TF_stage_KW_BH_recalculated.csv", row.names = FALSE)
cat("TF count:", nrow(out), "\n")
print(head(out, 15), row.names = FALSE)
cat("BH<0.05:", sum(out$BH < 0.05), "\n")
