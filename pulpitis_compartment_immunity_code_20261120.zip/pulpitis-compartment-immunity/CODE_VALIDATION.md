# Code release validation

Validation date: 20 November 2026 (local Windows environment).

- R scripts parsed without execution: 42; all passed using R 4.5.3.
- Python scripts parsed with ast: 2; all passed (`60_` and `61_`).
- Legacy `19i_`/`19j_` manuscript generators are excluded because they contain pre-QC manuscript text and could overwrite the audited DOCX files.
- Newly synchronized source-copy pairs checked byte-for-byte: 7; all matched.
- Figure 7 and Supplementary Figs. 29-33 were rebuilt into a separate working directory and compared with the submitted TIFFs.

| Figure | Dimensions | Pixel-identical |
|---|---:|---|
| Figure7.tif | 3030 x 2700 | yes |
| SupplementaryFig29.tif | 2160 x 2220 | yes |
| SupplementaryFig30.tif | 2520 x 2706 | yes |
| SupplementaryFig31.tif | 2040 x 2460 | yes |
| SupplementaryFig32.tif | 1600 x 1600 | yes |
| SupplementaryFig33.tif | 2760 x 1140 | yes |

Supplementary Fig. 33 is also byte-identical because the final script copies the R-native TIFF.

Scope limitation: these are syntax, source-integrity and figure-assembly checks. They are not a claim that every raw-data analysis was rerun end-to-end from this archive. Large public matrices and intermediate RDS objects are intentionally excluded; paths must be adapted before rerunning.

See `package_versions.csv` for installed package versions and `MANIFEST_SHA256.csv` for the release inventory.
